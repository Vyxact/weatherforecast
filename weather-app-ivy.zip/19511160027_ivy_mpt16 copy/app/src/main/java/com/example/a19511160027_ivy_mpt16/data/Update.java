package com.example.a19511160027_ivy_mpt16.data;

public class Update {
    public String loc;
    public String utc;

    @Override
    public String toString() {
        return "Update{" +
                "loc='" + loc + '\'' +
                ", utc='" + utc + '\'' +
                '}';
    }
}

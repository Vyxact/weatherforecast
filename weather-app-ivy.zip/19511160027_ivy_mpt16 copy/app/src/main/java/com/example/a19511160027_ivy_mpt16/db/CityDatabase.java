package com.example.a19511160027_ivy_mpt16.db;

import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;

import com.example.a19511160027_ivy_mpt16.data.City;

import java.util.ArrayList;
import java.util.List;


public class CityDatabase {

    public static final String KEY_ID = "mid";
    public static final String KEY_PID = "pid";
    public static final String KEY_NAME = "name";
    public static final String KEY_WEATHER_ID = "weather_id";
    public static final String KEY_EN_NAME = "en_name";
    public static final String KEY_INI_NAME = "ini_name";
    public static final String KEY_LEVEL = "level";
    public static final String KEY_LOOK_UP = "key_looK_up";
    private static final String DB_NAME = "citydb.db";
    public static final String CITY_TABLE = "city";
    private int version = 1;
    Activity activity;
    private SQLiteDatabase db;
    private DatabaseHelper databaseHelper;

    public CityDatabase(Activity activity) {
        this.activity = activity;
    }

    public void open() {
        if (db == null) {
            databaseHelper = new DatabaseHelper();
            db = databaseHelper.getWritableDatabase();
        }
    }

    public void close() {
        if (db != null && db.isOpen()) {
            db.close();
        }
    }

    public interface OnQueryFinished{
        public void onFinished(List<City> list);
    }
    interface LoadWork{
        List<City> queryWork();
    }
    private void asyncLoader(final OnQueryFinished listener,final LoadWork work){
        new Thread(new Runnable() {
            @Override
            public void run() {
                final List<City> list=work.queryWork();
                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        listener.onFinished(list);
                    }
                });
            }
        }).start();
    }
    public void queryAllProvinceAsync(final OnQueryFinished listener){
        asyncLoader(listener, new LoadWork() {
            @Override
            public List<City> queryWork() {
                return queryAllProvinces();
            }
        });
    }
    public City queryCityById(int Id, int level){
        String sql =String.format("select * from %s where %s=%d and %s=%d",CITY_TABLE,KEY_LEVEL,level,KEY_ID,Id);
        List<City> list = getCityListBySql(sql,null);
        if(list.size()>0){
            return list.get(0);
        }
        return null;
    }
    public void queryCityListByParentIdAsync(final int parentId, final int level,
    final OnQueryFinished listener) {

        asyncLoader(listener, new LoadWork() {
            @Override
            public List<City> queryWork() {
                return queryCityListByParentId(parentId,level);
            }
        });
    }
    public  void fuzzyQueryCityListAsync(final String match,final OnQueryFinished listener){
        asyncLoader(listener, new LoadWork() {
            @Override
            public List<City> queryWork() {
                return fuzzyQueryCityList(match);
            }
        });
    }
    class DatabaseHelper extends SQLiteOpenHelper {

        public DatabaseHelper() {
            super(activity, DB_NAME, null, version);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            String sql = String.format("create table if not exists %s " +
                            "(_id INTEGER PRIMARY KEY AUTOINCREMENT, %s int,%s int, %s text, %s text, %s text,%s int,%s text, %s text)",
                    CITY_TABLE, KEY_ID, KEY_PID, KEY_NAME, KEY_EN_NAME, KEY_INI_NAME, KEY_LEVEL, KEY_LOOK_UP, KEY_WEATHER_ID);
            db.execSQL(sql);

        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            resetData(db);
        }

        public void resetData(SQLiteDatabase db) {
            String sql = String.format("drop table if exists %s", CITY_TABLE);
            db.execSQL(sql);
            onCreate(db);
        }
    }

    private ContentValues enCodeContentValues(City city){

        ContentValues cv=new ContentValues();
        cv.put(KEY_EN_NAME,city.getEnName());
        cv.put(KEY_ID,city.getId());
        cv.put(KEY_INI_NAME,city.getInitialName());
        cv.put(KEY_LEVEL,city.getLevel());
        cv.put(KEY_LOOK_UP,generateLookup(city));
        cv.put(KEY_PID,city.getParentId());
        cv.put(KEY_WEATHER_ID,city.getWeather_id());
        cv.put(KEY_NAME,city.getName());

        return cv;

    }

    private String generateLookup(City city) {

        String name = city.getName();
        String enName = city.getEnName();
        String initialName = city.getInitialName();
        String[] enNameArray = enName.split("\\s");
        StringBuilder sb=new StringBuilder();
        sb.append(name+" |");
        sb.append(enName+" ");
        sb.append(initialName+" ");
        sb.append(enName.replaceAll("\\s"," ")+" ");
        for (int i = 0; i <enNameArray.length ; i++) {
            sb.append(initialName.substring(0, i));
            for (int j = 0; j < enNameArray.length; j++) {
                sb.append(enNameArray[j]);
            }
            sb.append(" ");
        }
        return sb.toString();
    }

    private City getCityFromCursor(Cursor c){
        String name=c.getString(c.getColumnIndex(KEY_NAME));
        String enname=c.getString(c.getColumnIndex(KEY_EN_NAME));
        String iniName=c.getString(c.getColumnIndex(KEY_INI_NAME));
        String weather_id=c.getString(c.getColumnIndex(KEY_WEATHER_ID));
        int id=c.getInt(c.getColumnIndex(KEY_ID));
        int pid=c.getInt(c.getColumnIndex(KEY_PID));
        int level =c.getInt(c.getColumnIndex(KEY_LEVEL));
        City city = new City(id,name,pid);
        city.setEnName(enname);
        city.setInitialName(iniName);
        city.setLevel(level);
        city.setWeather_id(weather_id);
        return city;
    }

    public long insertData(City city) {
        ContentValues cv = enCodeContentValues(city);
        return db.insert(CITY_TABLE, KEY_WEATHER_ID, cv);
    }
    public  List<City> fuzzyQueryCityList(String match){
        if(TextUtils.isEmpty(match)){
            return queryAllProvinces();
        }
        String sql= String.format("select * from %s where %s like ?",CITY_TABLE,KEY_LOOK_UP);
        String[] args= new String[]{"%"+match+"%"};
        return getCityListBySql(sql,args);
    }
    public int insertList(List<City> list) {
        int count = 0;
        for (int i = 0; i < list.size(); i++) {
            City city = list.get(i);
            if (insertData(city) > 0) {
                count++;
            }
        }
        return count;
    }
    public void clearDatabase() {
        if(db!= null && db.isOpen())
        databaseHelper.resetData(db);
    }
    public List<City> getCityListFromCursor(Cursor c) {
        List<City> list = new ArrayList<>();
        for (int i = 0; i < c.getCount(); i++) {
            c.moveToPosition(i);
            City city = getCityFromCursor(c);
            list.add(city);
        }
        return list;
    }
    public List<City> queryAllProvinces() {
        String sql = String. format ("select * from %s where %s=0", CITY_TABLE , KEY_LEVEL);
        return getCityListBySql(sql,null);
    }

    private List<City> getCityListBySql(String sql, String[]  args) {

        Cursor c = db.rawQuery(sql,args);
        List<City> list = getCityListFromCursor(c);
        c.close();
        return list;
    }
    public List<City> queryCityListByParentId(int parentId, int level) {
        if (level==0){
            return queryAllProvinces();
        }
        String sql = String.format("select * from %s where %s=%d and %s=%d", CITY_TABLE , KEY_PID ,parentId, KEY_LEVEL,level);
        return getCityListBySql(sql,null);
    }


}

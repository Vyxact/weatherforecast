package com.example.a19511160027_ivy_mpt16;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.a19511160027_ivy_mpt16.data.City;
import com.example.a19511160027_ivy_mpt16.db.CityDatabase;
import com.example.a19511160027_ivy_mpt16.db.GenerateDatabaseTask;
import com.example.a19511160027_ivy_mpt16.utility.HttpUtil;
import com.example.a19511160027_ivy_mpt16.utility.JsonUtil;
import com.example.a19511160027_ivy_mpt16.view.CityAdapter;

import org.json.JSONException;

import java.util.List;

public class SelectCityActivity extends AppCompatActivity {

    CityDatabase cityDatabase;
    ArrayAdapter<City> adapter;
    String baseUrl = "http://guolin.tech/api/china";
    ListView lv;
    Toolbar toolbar;
    int level_0_id;
    private static final String KEY_WEATHER_ID="key_weather_id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.select_city_main);

        lv=findViewById(R.id.listview);
        cityDatabase = new CityDatabase(this);
        cityDatabase.open();
        toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle("China");
        getAndUpdateCityList(baseUrl,-1,0);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                City city=adapter.getItem(position);
                int level=city.getLevel();
                int cityId= city.getId();
                int parentId= city.getParentId();
                String url;
                switch (level){
                    case 0:
                        level_0_id=cityId;
                        url=String.format("%s/%d",baseUrl,cityId);
                        getAndUpdateCityList(url,cityId,level+1);
                        break;
                    case 1:
                        url=String.format("%s/%d/%d", baseUrl,parentId,cityId);
                        getAndUpdateCityList(url,cityId,level+1);
                        break;
                    case 2:
                        String weather_id=city.getWeather_id();
                        Intent i=getIntent();
                        i.putExtra(KEY_WEATHER_ID,weather_id);
                        setResult(Activity.RESULT_OK,i);
                        finish();
                        break;
                }
            }
        });

    }
    public static String getWeatherIdByIntent(Intent i){
        return i.getStringExtra(KEY_WEATHER_ID);
    }
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.opt_menu,menu);
        MenuItem item = menu.findItem(R.id.opt_search);
        SearchView searchView = (SearchView)item.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(final String newText) {
                cityDatabase.fuzzyQueryCityListAsync(newText, new CityDatabase.OnQueryFinished() {
                    @Override
                    public void onFinished(List<City> list) {
                        updateListView(list);
                        if(TextUtils.isEmpty(newText)){
                            toolbar.setTitle("China");
                        }
                    }
                });
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }
    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        switch (item.getItemId()){
            case R.id.opt_back:
                back();
                break;
            case R.id.opt_quit:
                setResult(Activity.RESULT_CANCELED);
                finish();
                break;
            case R.id.opt_generate_db:
                new GenerateDatabaseTask(SelectCityActivity.this,cityDatabase).execute();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void back() {
        if(adapter.getCount()>0){
            City city=adapter.getItem(0);
            int level=city.getLevel();
            if(level==2){
                City city1=cityDatabase.queryCityById(city.getParentId(),1);
                level_0_id=city1.getParentId();
                String url= String.format("%s/%d",baseUrl,level_0_id);
                getAndUpdateCityList(url,level_0_id,level-1);
            }
            if(level==1){
                getAndUpdateCityList(baseUrl,-1,level-1);
            }
        }
    }

    private void showToast(String info) {

        Toast.makeText(this,info,Toast.LENGTH_SHORT).show();
    }

    private void getAndUpdateCityList(final String url, final int parentId, final int level) {

        cityDatabase.queryCityListByParentIdAsync(parentId, level, new CityDatabase.OnQueryFinished() {
            @Override
            public void onFinished(List<City> list) {
                if ((list == null) || list.size() == 0) {

                    HttpUtil.getOkHttpAsync(SelectCityActivity.this, url, new HttpUtil.SimpleAsyncCall() {
                        @Override
                        public void onFailure(String e) {

                        }

                        @Override
                        public void onResponse(String s) throws JSONException {

                            List<City> list= JsonUtil.getCityListFromJson(s,parentId,level);
                            cityDatabase.insertList(list);
                            showDbList(parentId,level);
                        }
                    });
                }else{
                    updateListView(list);
                }
                if(level==0){
                    toolbar.setTitle("China");
                }else{
                    City city=cityDatabase.queryCityById(parentId,level-1);
                    toolbar.setTitle(city.getName());
                }
            }
        });
    }

    private void showDbList(int parentId, int level) {

        cityDatabase.queryCityListByParentIdAsync(parentId, level, new CityDatabase.OnQueryFinished() {
            @Override
            public void onFinished(List<City> list) {
                updateListView(list);
            }
        });
    }

    private void updateListView(List<City> list) {
        adapter=new CityAdapter(this,list);
        lv.setAdapter(adapter);
    }


}

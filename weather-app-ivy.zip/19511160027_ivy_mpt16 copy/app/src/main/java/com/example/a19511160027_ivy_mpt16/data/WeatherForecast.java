package com.example.a19511160027_ivy_mpt16.data;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class WeatherForecast {
    public Basic basic;
    public Update update;
    public String status;
    @SerializedName("daily_forecast")
    public List<DailyForecast> dailyForecasts;

    @Override
    public String toString() {
        return "WeatherForecast{" +
                "basic=" + basic +
                ", update=" + update +
                ", status='" + status + '\'' +
                ", dailyForecasts=" + dailyForecasts +
                '}';
    }
}
